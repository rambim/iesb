# Projeto Integrador

## Leito.br
##### Seu portal de informações sobre o covid-19
\
&nbsp;

## Instalação dos requisitos.

* # Instalando dependencias do Frontend:
    * Entre na pasta "frontend";
    * Utilize o comando **yarn install** no terminal desse diretorio;
    * Após todas as dependencias terem sido instaladas utilize o comando **yarn start** no terminal desse diretorio.
\
&nbsp;

* # Instalando dependencias do Backend:
    * Entre na pasta "API";
    * Utiliza o comando **yarn install** no terminal desse diretorio;
    * Após todas as dependencias terem sido instaladas utiliza o comando **yarn start** no terminal desse diretorio.
\
&nbsp;

* # Instalando dependencias do Crawler:
    * Entre na pasta "crawler";
    * Utilize o comanddo **yarn install** no terminal desse diretorio;
    * Após todas as dependencias terem sido instaladas utilize o comando **yarn start** no terminal desse diretorio.