package analisealgp1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DynamicSubSetSum {
	
	static boolean Subsetsum(int conjunto[], int tam, int capacidade) {
			
		ArrayList<Integer> b = new ArrayList<>();
	
		boolean subset[][] = new boolean[tam][capacidade + 1 ];
		
		if(conjunto[0] > capacidade) {
			return false;
		}
		      
        for (int i = 0; i < tam; i++) 
            subset[i][0] = true; 
        
        for (int i = 1; i <= capacidade; i++) {      
            subset[0][i] = false;
        }
        
        for (int i = 1; i <= capacidade; i++) {   
        	for (int j = 0; j < tam; j++) {
        		if(conjunto[j] == i ) {
        			subset[0][i] = true;	
        		}
        		break;
        	}
        	
        }
                	
        for (int i = 1; i < tam; i++) 
        { 
            for (int j = 1; j <= capacidade; j++) 
            { 
            	if( j < conjunto[i]) {        		
            	subset[i][j] = subset[i-1][j];
            	}else {
            		if(subset[i-1][j] == false) {
            	subset[i][j] = subset[i-1][j - conjunto[i]];
            		}else {
            			subset[i][j] = true;
            		}
            			
            	}
               
            } 
        } 
        
        int sump = 0;
		int i = tam-1;
		int j = capacidade;
		
		if (subset[tam-1][capacidade]) {
			
			while (sump != capacidade && i >=0 && j>= 0) {	
				
				if ( subset[i][j] == true && subset[i-1][j] == false ) {
					
					
					  b.add(conjunto[i]); 
					  sump = sump + conjunto[i];
					  j = j - conjunto[i];
					  
					  i = i - 1;
					   
					  }
				else {
					
					i = i - 1;	
										
					  }								
				  }	 			
				}
		
		System.out.println(b);		
		return subset[tam-1][capacidade];
	}

	public static void main(String args[]) {
		int conjunto[] = {0,2,5,7,8,12}; //Para cada caso de teste incluir o '0' no �nicio do vetor
		int capacidade = 17;
		int tam = conjunto.length;
		if (Subsetsum(conjunto, tam, capacidade) == true)
			System.out.println("SubSet Encontrado");
		else
			System.out.println("Nenhum subset encontrado");
	}
}