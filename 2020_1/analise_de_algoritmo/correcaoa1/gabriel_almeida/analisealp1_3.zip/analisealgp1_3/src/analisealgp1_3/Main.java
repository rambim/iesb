package analisealgp1_3;

public class Main {

	public static void main(String[] args) {

        int conjunto[] = {3, 34, 4, 12, 5, 2}; 
        int capacidade = 17; 
 
		
        //int set[] = {10, 7, 5, 18, 12, 20, 15};
        
     
        SubsetSumBackTracking subBack = new SubsetSumBackTracking(conjunto, capacidade);
        subBack.subSetSumBackTracking(0,0);
 	    
        if(subBack.existeSubConjunto == false) {
        	System.out.print("N�o existe subconjunto que corresponda � capacidade");
        }
        
	}
}
