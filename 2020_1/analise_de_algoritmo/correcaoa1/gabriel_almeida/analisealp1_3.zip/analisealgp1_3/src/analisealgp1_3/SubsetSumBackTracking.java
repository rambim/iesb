package analisealgp1_3;

import java.util.Stack;

public class SubsetSumBackTracking {

	  int conjunto[];
	  int capacidade;
	  
	  Stack<Integer> pilhaDeSolucao;
	  boolean existeSubConjunto;
	  
	  SubsetSumBackTracking(int conjunto[], int sum){
	      this.conjunto = conjunto;
	      this.capacidade = sum;
	      this.pilhaDeSolucao = new Stack<>();
	      existeSubConjunto = false;
	  }
	  
	  public boolean subSetSumBackTracking(int somaTemp, int indicePilhaDeSolucao){   
       //Retorna false se a soma temporaria � maior que a capacidade
	    if(somaTemp>capacidade) {
	        return false;
	    }
	    //verifica se a pilha tem os numeros corretos para fechar a capacidade
	    if(somaTemp==capacidade){
	        existeSubConjunto = true;
	 
	       
	        mostraSubSets();
	 
	        //retorna false para podermos continuar procurando
	        return false;
	    }
	        
	    for(int i=indicePilhaDeSolucao; i<conjunto.length; i++){
	        
	        pilhaDeSolucao.push(conjunto[i]);
	 
	        
	        //soma o elemento conjunto[i] com a soma temporaria e come�a recursivamente do proximo numero
	        if(subSetSumBackTracking(somaTemp+conjunto[i],i+1)==true){
	            return true;
	        }
	 
	       
	        
	        //remove elemento do topo da pilha, isto �, remove a folha da arvore
	        pilhaDeSolucao.pop();
	    }
	    
	    //nenhuma combina�ao corresponde � capacidade
	    return false;
	  }
	  
	 
	  private void mostraSubSets(){
		  System.out.print("Subset: ");
	    for (int i =0;i< pilhaDeSolucao.size();i++){
	      System.out.print(pilhaDeSolucao.get(i)+" ");
	    }
	        System.out.println();
	    }
	
}