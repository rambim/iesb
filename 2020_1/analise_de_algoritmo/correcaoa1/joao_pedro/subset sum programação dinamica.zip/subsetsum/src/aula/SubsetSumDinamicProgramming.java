package aula;

import java.util.ArrayList;

public class SubsetSumDinamicProgramming {

    static boolean[][] dp; 
       
    static void mostrar(ArrayList<Integer> lista) 
    { 
       System.out.println(lista); 
    } 
       

    static void mostrarSubsets(int array[], int i, int soma,  
                                         ArrayList<Integer> lista) 
    { 

        if (i == 0 && soma != 0 && dp[0][soma]) 
        { 
            lista.add(array[i]); 
            mostrar(lista); 
            lista.clear(); 
            return; 
        } 
       
        if (i == 0 && soma == 0) 
        { 
            mostrar(lista); 
            lista.clear(); 
            return; 
        } 
       
        if (dp[i-1][soma]) 
        { 
            ArrayList<Integer> b = new ArrayList<>(); 
            b.addAll(lista); 
            mostrarSubsets(array, i-1, soma, b); 
        } 
       
        if (soma >= array[i] && dp[i-1][soma-array[i]]) 
        { 
            lista.add(array[i]); 
            mostrarSubsets(array, i-1, soma-array[i], lista); 
        } 
    } 
       
    static void mostrarTodosSubsets(int array[], int tamanhoArray, int soma) 
    { 
        if (tamanhoArray == 0 || soma < 0) 
           return; 
       
        dp = new boolean[tamanhoArray][soma + 1]; 
        for (int i=0; i<tamanhoArray; ++i) 
        { 
            dp[i][0] = true;   
        } 
       
        if (array[0] <= soma) {
        	dp[0][array[0]] = true;    	
        }
        
        
        
        for (int i = 1; i < tamanhoArray; ++i) 
            for (int j = 0; j < soma + 1; ++j) 
                dp[i][j] = (array[i] <= j) ? (dp[i-1][j] || dp[i-1][j-array[i]]) : dp[i - 1][j]; 
              
                
        if (dp[tamanhoArray-1][soma] == false) 
        { 
            System.out.println("There are no subsets with" +  
                                                  " sum "+ soma); 
            return; 
        } 
       
        ArrayList<Integer> p = new ArrayList<>(); 
        mostrarSubsets(array, tamanhoArray-1, soma, p);
     
    } 
       
    public static void main(String args[]) 
    { 
        int arr[] = {1, 2, 3, 4}; 
        int n = arr.length; 
        int sum = 5; 
        mostrarTodosSubsets(arr, n, sum); 
    } 
}